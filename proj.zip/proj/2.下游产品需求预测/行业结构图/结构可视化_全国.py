# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline

# ---------- 基本参数 ----------
sce = '基准'
base_dir = f'/lustre/home/litong/intern/京津冀货运发展/output/2.消费需求预测/Sce_{sce}/全国完整数据/'
out_dir = os.path.join(base_dir, '典型行业下游结构图')
os.makedirs(out_dir, exist_ok=True)

target_steel_file = os.path.join(base_dir, '分省钢铁消费量预测.xlsx')
target_cement_file = os.path.join(base_dir, '分省水泥消费量预测.xlsx')
src_steel_file  = os.path.join(base_dir, '下游行业用钢需求预测.xlsx')
src_cement_file = os.path.join(base_dir, '下游行业水泥需求预测.xlsx')

steel_stream  = ['新增建筑面积','汽车产量','新增铁路里程','洗衣机产量','电冰箱产量','空调产量']
cement_stream = ['新增建筑面积','新增高速公路里程','新增其他等级公路里程','新增铁路里程','农村水电基础设施投资']

years_plot = np.array(range(2010, 2036))
# 定义新颜色 (模仿图一风格)
# 蓝色系、灰色系、橙黄色系
custom_colors = ['#5da5da', '#faa43a', '#a6a6a6', '#f17cb0', '#b2912f', '#88c4a6']

plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'Droid Sans Fallback', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

# ---------- 工具函数 ----------

def smooth_dataframe(df, points=300):
    """使用插值使 DataFrame 平滑化"""
    x = df.index.values
    x_new = np.linspace(x.min(), x.max(), points)
    df_smooth = pd.DataFrame(index=x_new)
    for col in df.columns:
        spl = make_interp_spline(x, df[col], k=3) # k=3 为三次样条
        df_smooth[col] = spl(x_new).clip(min=0) # 确保插值后不出现负数
    return df_smooth

def build_scaled_stacked_df(src_xlsx, target_xlsx, sectors, suffix):
    df_target = pd.read_excel(target_xlsx, index_col=0)
    target_series = df_target['全国'].reindex(years_plot).fillna(0)

    series_list = []
    for s in sectors:
        sheet_name = f'{s}_{suffix}'
        df = pd.read_excel(src_xlsx, sheet_name=sheet_name, index_col=0)
        numeric_df = df.select_dtypes(include='number')
        nat = numeric_df['全国'].copy() if '全国' in numeric_df.columns else numeric_df.sum(axis=1)
        series_list.append(nat.reindex(years_plot).fillna(0).clip(lower=0))
    
    df_src = pd.concat(series_list, axis=1)
    df_src.columns = sectors
    
    # 缩放逻辑
    current_total = df_src.sum(axis=1)
    scale_ratio = target_series / current_total
    scale_ratio = scale_ratio.replace([np.inf, -np.inf], 0).fillna(0)
    return df_src.mul(scale_ratio, axis=0)

def plot_smooth_structure(df: pd.DataFrame, title: str, colors: list, ylabel: str, out_png: str = None):
    """绘制平滑的堆叠面积图"""
    # 排序：让较大的行业在底部，视觉更稳
    order = df.mean().sort_values(ascending=False).index.tolist()
    df_ordered = df[order]
    
    # 插值平滑
    df_plot = smooth_dataframe(df_ordered)
    
    x = df_plot.index.values
    y = df_plot.T.values 

    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=300)
    
    # 绘制堆叠图 (去掉线条 linewidth=0)
    ax.stackplot(x, y, labels=df_plot.columns.tolist(), 
                 colors=colors[:df_plot.shape[1]], 
                 alpha=0.85, linewidth=0)

    ax.set_xlim(years_plot.min(), years_plot.max())
    ax.set_xlabel('Year', fontsize=10)
    ax.set_ylabel(ylabel, fontsize=10)
    ax.set_title(title, fontsize=12, pad=15)
    
    # 格式美化
    ax.set_ylim(bottom=0)
    ax.grid(axis='y', linestyle='--', alpha=0.3)
    ax.tick_params(axis='both', which='major', labelsize=9)
    
    # 图例样式模仿图一
    leg = ax.legend(loc='center left', bbox_to_anchor=(1.02, 0.5), 
                    frameon=False, fontsize=9)

    plt.tight_layout()
    if out_png:
        plt.savefig(out_png, bbox_inches='tight')
        print(f'已生成平滑结构图：{out_png}')
    plt.show()
    plt.close()

# ---------- 执行主流程 ----------

# 1. 钢铁
if os.path.exists(src_steel_file):
    steel_df = build_scaled_stacked_df(src_steel_file, target_steel_file, steel_stream, '中间结果')
    plot_smooth_structure(
        df=steel_df,
        title='全国钢铁行业下游产品生产需求结构',
        colors=custom_colors,
        ylabel='生产需求 (吨)',
        out_png=os.path.join(out_dir, '全国_钢铁消费结构.png')
    )

# 2. 水泥
if os.path.exists(src_cement_file):
    cement_df = build_scaled_stacked_df(src_cement_file, target_cement_file, cement_stream, '中间结果')
    
    # 水泥 2024 特殊插值修正 (先修正原始离散点，再进行整体曲线平滑)
    if 2023 in cement_df.index and 2025 in cement_df.index:
        cement_df.loc[2024] = (cement_df.loc[2023] + cement_df.loc[2025]) / 2.0
    
    plot_smooth_structure(
        df=cement_df,
        title='全国水泥行业下游产品生产需求结构',
        colors=custom_colors,
        ylabel='生产需求 (吨)',
        out_png=os.path.join(out_dir, '全国_水泥消费结构.png')
    )