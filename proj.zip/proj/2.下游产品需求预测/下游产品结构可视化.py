# -*- coding: utf-8 -*-
"""
绘制钢铁下游产品结构图（逐年）
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from matplotlib.ticker import FuncFormatter

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'Droid Sans Fallback', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号
plt.rcParams['font.size'] = 12  # 全局字体大小

scenario_name = '高增长'

def load_steel_downstream_data(data_dir):
    """
    加载钢铁下游产品的预测数据
    data_dir: 存放CSV文件的目录
    return: 合并后的全国年度数据
    """
    # 产品映射关系：{显示名称: (文件名, 预测列名)}
    product_mapping = {
        '建筑业（新增建筑面积）': ('分省新增建筑面积完整结果.csv', '新增建筑面积'),
        '汽车制造业（汽车产量）': ('分省汽车产量完整结果.csv', '汽车产量'),
        '铁路运输（新增铁路里程）': ('分省新增铁路里程完整结果.csv', '新增铁路里程'),
        '家电（洗衣机）': ('分省洗衣机产量完整结果.csv', '洗衣机产量'),
        '家电（电冰箱）': ('分省电冰箱产量完整结果.csv', '电冰箱产量'),
        '家电（空调）': ('分省空调产量完整结果.csv', '空调产量'),
        '公路建设（高速公路）': ('分省新增高速公路里程完整结果.csv', '新增高速公路里程'),
        '公路建设（其他等级公路）': ('分省新增其他等级公路里程完整结果.csv', '新增其他等级公路里程')
        #'电力（农村水电）': ('分省农村水电基础设施投资完整结果.csv', '农村水电基础设施投资')
    }
    
    product_data = {}  # 存储各产品数据
    
    # 遍历所有产品
    for product_name, (filename, predict_col) in product_mapping.items():
        file_path = os.path.join(data_dir, filename)
        
        # 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"⚠️ 警告：文件不存在 - {file_path}")
            continue
        
        # 读取文件
        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            print(f"❌ 读取文件失败 {filename}：{str(e)}")
            continue
        
        # 检查年份列是否存在
        if '年份' not in df.columns:
            print(f"❌ 文件 {filename} 中没有'年份'列，列名：{df.columns.tolist()}")
            continue
            
        # 检查预测列是否存在
        if predict_col not in df.columns:
            print(f"❌ 文件 {filename} 中没有'{predict_col}'列，列名：{df.columns.tolist()}")
            continue
        
        # 按年份汇总
        try:
            # 确保年份为整数
            df['年份'] = pd.to_numeric(df['年份'], downcast='integer', errors='coerce')
            df = df.dropna(subset=['年份'])  # 移除年份无效的行
            
            # 按年份求和
            national_yearly = df.groupby('年份')[predict_col].sum().reset_index()
            national_yearly.rename(columns={predict_col: product_name}, inplace=True)
            product_data[product_name] = national_yearly
            print(f"✅ 成功加载：{product_name}")
        except Exception as e:
            print(f"❌ 处理 {product_name} 时出错：{str(e)}")
            continue
    
    # 检查是否有有效数据
    if not product_data:
        raise ValueError("没有加载到任何有效数据，请检查文件路径和列名是否正确")
    
    # 合并所有产品数据
    try:
        merged_df = next(iter(product_data.values())).copy()
        for product_name, df in product_data.items():
            if product_name != merged_df.columns[1]:
                merged_df = pd.merge(merged_df, df, on='年份', how='outer')
        
        # 排序并处理缺失值
        merged_df = merged_df.sort_values('年份').reset_index(drop=True)
        merged_df['年份'] = merged_df['年份'].astype(int)
        merged_df = merged_df.fillna(0)
        return merged_df
    except Exception as e:
        raise RuntimeError(f"合并数据时出错：{str(e)}")

def plot_steel_downstream_structure(merged_df, output_dir):
    """绘制钢铁下游产品结构堆叠柱状图"""
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 提取数据
    years = merged_df['年份'].astype(int)
    products = [col for col in merged_df.columns if col != '年份']
    
    if len(products) == 0:
        raise ValueError("没有可绘制的产品数据")
    
    # 计算总量和占比
    yearly_total = merged_df[products].sum(axis=1)
    
    # 创建画布
    plt.figure(figsize=(16, 9))
    prev_bottom = np.zeros(len(years))
    colors = plt.cm.Set3(np.linspace(0, 1, len(products)))  # 颜色方案
    
    # 绘制堆叠柱状图
    for i, product in enumerate(products):
        product_ratio = merged_df[product] / yearly_total * 100
        plt.bar(
            years, product_ratio, 
            bottom=prev_bottom, 
            color=colors[i], 
            edgecolor='white', 
            linewidth=0.8,
            width=0.6,
            label=product
        )
        prev_bottom += product_ratio
    
    # 设置图表属性
    plt.title('钢铁下游产品需求结构变化（按占比）', fontsize=18, pad=20)
    plt.xlabel('年份', fontsize=14, labelpad=10)
    plt.ylabel('占比（%）', fontsize=14, labelpad=10)
    plt.xticks(years, rotation=45, ha='right')  # 年份旋转45度
    plt.ylim(0, 100)  # 百分比限制在0-100
    
    # 设置y轴百分比格式
    plt.gca().yaxis.set_major_formatter(FuncFormatter(lambda y, _: f'{y:.0f}%'))
    
    # 添加图例
    plt.legend(
        bbox_to_anchor=(1.02, 1), 
        loc='upper left', 
        fontsize=11,
        frameon=True,
        edgecolor='lightgrey'
    )
    
    # 添加网格线
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图像
    save_path = os.path.join(output_dir, '钢铁下游产品结构逐年变化.png')
    try:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"📊 图表已保存至：{save_path}")
    except Exception as e:
        print(f"❌ 保存图表失败：{str(e)}")
    
    plt.close()

def main():
    # 数据目录
    data_dir = f'/lustre/home/litong/intern/京津冀货运发展/output/2.消费需求预测/Sce_{scenario_name}/全国完整数据'
    # 输出目录
    output_dir = os.path.join(data_dir, '钢铁下游结构图')
    
    try:
        print("===== 开始加载数据 =====")
        downstream_data = load_steel_downstream_data(data_dir)
        
        # 显示数据信息
        print("\n===== 数据加载完成 =====")
        print(f"包含年份范围：{downstream_data['年份'].min()} - {downstream_data['年份'].max()}")
        print(f"包含产品数量：{len(downstream_data.columns) - 1} 个")
        print(f"产品列表：{[col for col in downstream_data.columns if col != '年份']}")
        
        # 绘制图表
        print("\n===== 开始绘制图表 =====")
        plot_steel_downstream_structure(downstream_data, output_dir)
        
        print("\n===== 所有操作完成 =====")
        
    except Exception as e:
        print(f"\n❌ 程序异常终止：{str(e)}")
        exit(1)

if __name__ == "__main__":
    main()
