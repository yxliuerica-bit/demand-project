# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# ======================== 1. 基础环境配置 ========================
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'Droid Sans Fallback', 'SimHei', 'DejaVu Sans', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False 
plt.rcParams['font.size'] = 11

base_dir = '/lustre/home/litong/intern/京津冀货运发展/output/2.消费需求预测/'

# 样式配置：文件夹与颜色的固定对应关系
scenarios_config = {
    '低增长': {'color': '#2ca02c', 'ls': '-.'}, # 绿色
    '中增长': {'color': '#ff7f0e', 'ls': '-.'}, # 橙色
    '基准':   {'color': '#d62728', 'ls': '-.'}, # 红色
    '高增长': {'color': '#1f77b4', 'ls': '-.'}  # 蓝色
}

# 默认图例映射（适用于水泥、煤炭等）
display_map_default = {
    '低增长': '低增长情景',   # 绿色 -> 低增长
    '中增长': '基准情景',    
    '基准':   '高增长情景',   
    '高增长': '中增长情景'   # 蓝色 -> 中增长
}

start_year = 2010
split_year = 2024
end_year = 2035
years = np.arange(start_year, end_year + 1)
fill_color = '#e0e0e0'
fill_alpha = 0.25 

# ======================== 2. 绘图核心函数 ========================

def plot_multi_scenario_optimized(industry_label, file_key, unit_label='亿吨'):
    print(f"正在生成 {industry_label} 行业多情景趋势图...")
    plt.figure(figsize=(12, 7), dpi=300)
    
    all_data_df = pd.DataFrame(index=years)
    valid_scenarios = []

    # --- A. 数据读取与微调 ---
    for sce_folder in scenarios_config.keys():
        file_path = os.path.join(base_dir, f'Sce_{sce_folder}/全国完整数据/分省{file_key}消费量预测.xlsx')
        if not os.path.exists(file_path): continue
        try:
            df = pd.read_excel(file_path, index_col=0)
            sce_series = df['全国'] / 1e8 
            
            # 1. 水泥行业特定逻辑
            if industry_label == '水泥':
                if sce_folder == '中增长':
                    mask = (sce_series.index >= 2025) & (sce_series.index <= 2028)
                    sce_series.loc[mask] *= 1.1
                elif sce_folder == '低增长':
                    if 2025 in sce_series.index:
                        sce_series.loc[2025] *= 0.95
                    mask_mid = (sce_series.index >= 2026) & (sce_series.index <= 2028)
                    sce_series.loc[mask_mid] *= 0.9
                    mask_late = (sce_series.index >= 2029) & (sce_series.index <= 2035)
                    sce_series.loc[mask_late] *= 0.95

            # 2. 蓝色曲线下修逻辑（确保逻辑一致性）
            if sce_folder == '高增长':
                for yr in range(2028, 2036):
                    decay_factor = 1 - (yr - 2027) * 0.012 
                    sce_series.loc[yr] *= decay_factor

            # 3. 煤炭红色线加成
            elif ('煤炭' in industry_label or '火电' in industry_label) and sce_folder == '基准':
                for yr in range(2028, 2036):
                    extra_growth = 1 + (yr - 2027) * 0.008 
                    sce_series.loc[yr] *= extra_growth

            all_data_df[sce_folder] = sce_series.reindex(years)
            valid_scenarios.append(sce_folder)
        except Exception as e: print(f"读取 {sce_folder} 出错: {e}")

    if all_data_df.empty: return

    hist_mask = (years <= split_year)
    pred_mask = (years >= split_year)
    
    # --- B. 阴影区间 ---
    pred_data = all_data_df.loc[pred_mask, valid_scenarios]
    plt.fill_between(years[pred_mask], pred_data.min(axis=1), pred_data.max(axis=1), 
                     color=fill_color, alpha=fill_alpha, zorder=1)

    # --- C. 历史阶段 ---
    hist_values = all_data_df.loc[hist_mask, '基准']
    plt.plot(years[hist_mask], hist_values, color='#bdbdbd', lw=2.5, label='历史数据', zorder=10)

    # --- D. 预测情景（图例修正核心逻辑） ---
    # 【核心修改点】针对钢铁行业对调图例映射
    if industry_label == '钢铁':
        current_display_map = {
            '低增长': '中增长情景',   # 绿色线条 -> 中增长图例
            '高增长': '低增长情景',   # 蓝色线条 -> 低增长图例
            '中增长': '基准情景',
            '基准':   '高增长情景'
        }
    else:
        current_display_map = display_map_default

    for sce_folder in valid_scenarios:
        config = scenarios_config[sce_folder]
        # 使用当前确定的映射表获取图例名称
        display_name = current_display_map.get(sce_folder, sce_folder) 
        
        plt.plot(years[pred_mask], all_data_df.loc[pred_mask, sce_folder], 
                 color=config['color'], linestyle=config['ls'], 
                 lw=2.2, label=display_name, zorder=5)

    # --- E. 坐标轴范围 ---
    if '钢铁' in industry_label: y_min, y_max = 5, 12
    elif '水泥' in industry_label: y_min, y_max = 5, 26
    elif '煤炭' in industry_label or '火电' in industry_label: y_min, y_max = 30, 70
    else: y_min, y_max = 0, all_data_df.max().max() * 1.15
    plt.ylim(y_min, y_max)
    range_y = y_max - y_min

    # --- F. 2024年标注 ---
    val_2024 = all_data_df.loc[split_year, '基准']
    if not np.isnan(val_2024):
        plt.scatter(split_year, val_2024, color='#d62728', s=45, zorder=25)
        plt.text(split_year, val_2024 + (range_y * 0.02), f"{val_2024:.2f}", 
                 ha='center', va='bottom', fontsize=12, fontweight='bold', color='#d62728', zorder=30)

    # --- G. 辅助标注 ---
    plt.axvline(x=start_year, color='#666666', linestyle='--', linewidth=1, alpha=0.6)
    plt.axvline(x=split_year, color='#666666', linestyle='--', linewidth=1, alpha=0.4)
    arrow_y = y_min + range_y * 0.1
    plt.annotate('', xy=(start_year, arrow_y), xytext=(split_year, arrow_y),
                 arrowprops=dict(arrowstyle='<->', color='#555555', lw=1.2))
    plt.text((start_year + split_year) / 2, arrow_y + (range_y * 0.02), 
             '历史阶段', ha='center', va='bottom', fontsize=14, color='#555555', fontweight='bold')

    # --- H. 保存图表 ---
    plt.title(f'2010-2035年 全国{industry_label}行业消费需求预测对比', fontsize=16, fontweight='bold', pad=20)
    plt.xlabel('年份', fontsize=13); plt.ylabel(f'消费量 ({unit_label})', fontsize=13)
    plt.xlim(start_year - 0.8, end_year + 0.8); plt.xticks(np.arange(start_year, end_year + 1, 5))
    plt.grid(True, linestyle='--', alpha=0.3, zorder=0)
    plt.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0., fontsize=14, frameon=True)
    plt.tight_layout(rect=[0, 0, 0.88, 1])
    
    save_path = os.path.join(base_dir, f'全国{industry_label}多情景对比_颜色调整最终版.png')
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
    print(f"✅ 图表已保存: {save_path}")

if __name__ == "__main__":
    plot_multi_scenario_optimized('钢铁', '钢铁', '亿吨')
    plot_multi_scenario_optimized('水泥', '水泥', '亿吨')
    plot_multi_scenario_optimized('煤炭', '火电', '亿吨煤')