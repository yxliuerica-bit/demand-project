# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# ======================== 1. 基础环境配置 ========================
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'Droid Sans Fallback', 'SimHei', 'DejaVu Sans', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False 
plt.rcParams['font.size'] = 11

# 路径配置
base_dir = '/lustre/home/litong/intern/京津冀货运发展/output/2.消费需求预测/'

# 情景样式配置
scenarios = {
    '低增长': {'color': '#1f77b4', 'ls': '-.'},
    '中增长': {'color': '#ff7f0e', 'ls': '-.'},
    '基准':   {'color': '#d62728', 'ls': '-.'},
    '高增长': {'color': '#2ca02c', 'ls': '-.'}
}

start_year = 2010
split_year = 2024
end_year = 2035
years = np.arange(start_year, end_year + 1)

fill_color = '#e0e0e0'
fill_alpha = 0.25 

# ======================== 2. 绘图核心函数 ========================

def plot_multi_scenario_optimized(industry_label, file_key, unit_label='亿吨'):
    print(f"正在生成 {industry_label} 行业多情景趋势图...")
    plt.figure(figsize=(12, 7), dpi=300)
    
    all_data_df = pd.DataFrame(index=years)
    
    # --- A. 数据读取与汇总 ---
    valid_scenarios = []
    for sce_name in scenarios.keys():
        file_path = os.path.join(base_dir, f'Sce_{sce_name}/全国完整数据/分省{file_key}消费量预测.xlsx')
        if not os.path.exists(file_path):
            continue
        try:
            df = pd.read_excel(file_path, index_col=0)
            sce_series = df['全国'] / 1e8 
            all_data_df[sce_name] = sce_series.reindex(years)
            valid_scenarios.append(sce_name)
        except Exception as e:
            print(f"读取 {sce_name} 出错: {e}")

    if all_data_df.empty:
        return

    hist_mask = (years <= split_year)
    pred_mask = (years >= split_year)
    hist_years = years[hist_mask]
    pred_years = years[pred_mask]

    # --- B. 预测背景阴影 ---
    pred_data = all_data_df.loc[pred_mask, valid_scenarios]
    max_pred, min_pred = pred_data.max(axis=1), pred_data.min(axis=1)
    plt.fill_between(pred_years, min_pred, max_pred, color=fill_color, alpha=fill_alpha, zorder=1)

    # --- C. 历史阶段曲线 ---
    ref_sce = '基准' if '基准' in valid_scenarios else valid_scenarios[0]
    hist_values = all_data_df.loc[hist_mask, ref_sce]
    plt.plot(hist_years, hist_values, color='#bdbdbd', lw=2.5, label='历史数据', zorder=10)

    # --- D. 各情景预测曲线 ---
    for sce_name in valid_scenarios:
        config = scenarios[sce_name]
        plt.plot(pred_years, all_data_df.loc[pred_mask, sce_name], 
                 color=config['color'], linestyle=config['ls'], 
                 lw=2.2, label=f'{sce_name}情景', zorder=5)

    # --- E. 固定 Y 轴范围 ---
    if '钢铁' in industry_label:
        y_min, y_max = 5, 12
    elif '水泥' in industry_label:
        y_min, y_max = 5, 26
    elif '煤炭' in industry_label or '火电' in industry_label:
        y_min, y_max = 30, 70
    else:
        y_min, y_max = 0, all_data_df.max().max() * 1.15

    plt.ylim(y_min, y_max)
    range_y = y_max - y_min

    # --- F. 【修改点】2024 年红色锚点与纯文本标注 ---
    val_2024 = all_data_df.loc[split_year, ref_sce]
    if not np.isnan(val_2024):
        # 绘制红色锚点
        plt.scatter(split_year, val_2024, color='#d62728', s=45, zorder=25)
        
        # 直接在点上方标注文字 (通过 va='bottom' 确保在点上方)
        # 增加偏移量 (range_y * 0.02) 以免重叠
        plt.text(split_year, val_2024 + (range_y * 0.02), 
                 f"{val_2024:.2f}", 
                 ha='center', va='bottom', 
                 fontsize=18, fontweight='bold', color='#d62728',
                 zorder=30)

    # --- G. 边界虚线与 Historical 双箭头 ---
    plt.axvline(x=start_year, color='#666666', linestyle='--', linewidth=1, alpha=0.6, zorder=2)
    plt.axvline(x=split_year, color='#666666', linestyle='--', linewidth=1, alpha=0.4, zorder=2)
    
    arrow_y = y_min + range_y * 0.1
    plt.annotate('', xy=(start_year, arrow_y), xytext=(split_year, arrow_y),
                 arrowprops=dict(arrowstyle='<->', color='#555555', lw=1.2))
    
    plt.text((start_year + split_year) / 2, arrow_y + (range_y * 0.02), 
             '历史阶段', ha='center', va='bottom', fontsize=14, color='#555555', fontweight='bold')

    # --- H. 图表美化与保存 ---
    plt.title(f'2010-2035年 全国{industry_label}行业消费需求预测对比', fontsize=16, fontweight='bold', pad=20)
    plt.xlabel('年份', fontsize=13)
    plt.ylabel(f'消费量 ({unit_label})', fontsize=13)
    plt.xlim(start_year - 0.8, end_year + 0.8)
    plt.xticks(np.arange(start_year, end_year + 1, 5))
    plt.grid(True, linestyle='--', alpha=0.3, zorder=0)
    plt.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0., fontsize=14, frameon=True)
    
    plt.tight_layout(rect=[0, 0, 0.88, 1])
    
    save_path = os.path.join(base_dir, f'全国{industry_label}多情景对比趋势图_标注精简版.png')
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
    print(f"✅ 图表已保存: {save_path}")

# ======================== 3. 执行主程序 ========================

if __name__ == "__main__":
    plot_multi_scenario_optimized('钢铁', '钢铁', '亿吨')
    plot_multi_scenario_optimized('水泥', '水泥', '亿吨')
    plot_multi_scenario_optimized('煤炭', '火电', '亿吨煤')